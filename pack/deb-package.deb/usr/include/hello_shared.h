#ifndef MY_LIBRARY_H
#define MY_LIBRARY_H

void say_hello();

#endif